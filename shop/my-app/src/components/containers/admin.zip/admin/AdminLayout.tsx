import { Outlet } from "react-router-dom";
import AdminHeader from "./AdminHeader";

const AdminLayout = () => {
    return (
        <>
            <AdminHeader />
            <main>
                <Outlet />
            </main>
        </>
    );
}
export default AdminLayout;