import AdminLayout from "./AdminLayout";

export default AdminLayout;