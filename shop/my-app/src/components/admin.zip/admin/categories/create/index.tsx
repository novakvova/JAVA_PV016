import AdminCategoryCreatePage from "./AdminCategoryCreatePage";

export default AdminCategoryCreatePage;