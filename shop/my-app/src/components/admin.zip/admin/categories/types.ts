export interface ICategoryCreate {
    name: string;
    file: File | null;
    description: string;
};